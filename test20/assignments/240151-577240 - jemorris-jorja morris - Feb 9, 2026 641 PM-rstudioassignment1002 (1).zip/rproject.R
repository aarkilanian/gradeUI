> install.packages("dplyr")
> > moosedata <- read.csv("MoosePopulation.csv")
> setwd("..")
> setwd("/cloud/project")
> setwd("path/to/your/folder")
> moosedata <- read.csv("/mnt/data/MoosePopulation.csv")
> setwd("/cloud/project/MoosePopulation")
> setwd("/cloud/project/MoosePopulation")
> library(readr)
> MoosePopulation_csv_0A <- read_csv("MoosePopulation/MoosePopulation.csv%0A.csv")
Rows: 54 Columns: 6                        
── Column specification ─────────────────────
Delimiter: ","
chr (3): Ecoregion, Observation_Method, D...
dbl (3): Year, Area, Estimated_Moose_Pop

ℹ Use `spec()` to retrieve the full column specification for this data.
ℹ Specify the column types or set `show_col_types = FALSE` to quiet this message.
> View(MoosePopulation_csv_0A)
> View(MoosePopulation_csv_0A)
> View(MoosePopulation_csv_0A)
> View(MoosePopulation_csv_0A)
> View(moose_clean)
> moose_clean <- na.omit(moosedata)
> moose_clean <- na.omit(moosedata)
> moosedata <- read.csv("data/MoosePopulation.csv")
> moosedata <- read.csv("MoosePopulation.csv")
> setwd("/cloud/project/moosedata/MoosePopulation")
> moosedata <- read.csv("data/MoosePopulation.csv")
> moosedata <- read.csv("MoosePopulation.csv")
> list.files()
[1] "moose"                     
[2] "moose_clean"               
[3] "MoosePopulation.csv%0A.csv"
> moosedata <- read.csv("data/MoosePopulation.csv")
> moosedata <- read.csv("MoosePopulation.csv")
> moose_clean <- na.omit(moosedata)
> moose_sel <- moose_clean[, c("Ecoregion", "Year", "Area", "Estimated_Moose_Pop, Observation_Method, Data_Source")]
> moose_sel <- moose_clean[, c("Ecoregion", "Year", "Area", "Estimated_Moose_Pop")]
> year_min <- min(moose_sel$Year)
> moose_max <- gmax(moose_sel$Estimated_Moose_Pop)
> moose_max <- max(moose_sel$Estimated_Moose_Pop)
> moosedata2 <- mutate(
  +     moose_sel,
  +     MooseDensity = Estimated_Moose_Pop / Area
  + )
> moosedata2 <- mutate(moose_sel,MooseDensity = Estimated_Moose_Pop / Area)
> moosedata2 <- mutate(
  +     moose_sel,
  +     MooseDensity = Estimated_Moose_Pop / Area
  + )
> moosedata2 <- mutate(moose_sel,
                       +                      MooseDensity = Estimated_Moose_Pop / Area)
> moosedata2 <- mutate(moose_sel, MooseDensity = Estimated_Moose_Pop / Area)
> library(dplyr)
> moosedata2 <- mutate(
  +     moose_sel,
  +     MooseDensity = Estimated_Moose_Pop / Area
  + )
> plot(
  +     moosedata2$Year,
  +     moosedata2$MooseDensity,
  +     type = "l",   # makes it a line graph
  +     xlab = "Year",
  +     ylab = "Moose per sq km",
  +     main = "Moose density in Newfoundland ecoregions over time"
  + )
> moose_west <- filter(moosedata2, Ecoregion == "Western_Forests")
> plot(
  +     moose_west$Year,
  +     moose_west$MooseDensity,
  +     type = "l",
  +     xlab = "Year",
  +     ylab = "Moose per sq km",
  +     main = "Moose density over time in the Western Forests ecoregion"
  + )
> library(dplyr)
> > moose_2020 <- filter(moosedata2, Year == 2020)
> moose_2020_high <- filter(moose_2020, MooseDensity > 2.0)
> moose_2020_high_byD <- arrange(moose_2020_high, desc(MooseDensity))
> library(dplyr)
> > moosefinal <- moosedata2 %>%
  +     filter(Year == 2020) %>%
  +     filter(MooseDensity > 2.0) %>%
  +     arrange(desc(MooseDensity)) %>%
  +     print()
Ecoregion Year  Area
1 Northern_Peninsula_Forests 2020 12000
2        North_Shore_Forests 2020  8400
3            Western_Forests 2020  6800
4            Central_Forests 2020 20500
Estimated_Moose_Pop MooseDensity
1               32000     2.666667
2               21740     2.588095
3               17000     2.500000
4               41250     2.012195
> saplings <- read.csv("SaplingStudy.csv")
> setwd("..")
> library(readr)
> SaplingStudy <- read_csv("../SaplingStudy.csv")
Rows: 45 Columns: 5                        
── Column specification ─────────────────────
Delimiter: ","
chr (3): Ecoregion, Tree_ID, Species
dbl (2): Height, BrowsingScore

ℹ Use `spec()` to retrieve the full column specification for this data.
ℹ Specify the column types or set `show_col_types = FALSE` to quiet this message.
> View(SaplingStudy)
> setwd("/cloud/project/moosedata/MoosePopulation")
> setwd("/cloud/project")
> setwd("/cloud/project")
> saplings <- read.csv("SaplingStudy.csv")
> sap_clean <- na.omit(saplings)
> library(dplyr)
> > sap_reg_browse <- sap_clean %>%
  +     group_by(Ecoregion) %>%
  +     summarize(
    +         AverageBrowsing = mean(BrowsingScore)
    +     ) %>%
  +     print()
# A tibble: 9 × 2
Ecoregion                  AverageBrowsing
<chr>                                <dbl>
  1 Avalon_Forests                        2   
2 Central_Forests                       4   
3 EasternHyperOceanicBarrens            2.4 
4 Long_Range_Barrens                    2.6 
5 Maritime_Barrens                      1.83
6 North_Shore_Forests                   4.38
7 Northern_Peninsula_Forests            4.57
8 StraitOfBelleIsleBarrens              1   
9 Western_Forests                       4.5 
> avg_browse_reg <- sap_reg_browse %>%
  +     arrange(desc(AverageBrowsing))
> library(dplyr)
> > sap_reg_height <- sap_clean %>%
  +     group_by(Ecoregion) %>%
  +     summarize(
    +         AverageHeight = mean(Height)
    +     ) %>%
  +     print()
# A tibble: 9 × 2
Ecoregion                  AverageHeight
<chr>                              <dbl>
  1 Avalon_Forests                      32.4
2 Central_Forests                     23.8
3 EasternHyperOceanicBarrens          31.6
4 Long_Range_Barrens                  29.9
5 Maritime_Barrens                    26.7
6 North_Shore_Forests                 22.3
7 Northern_Peninsula_Forests          19.9
8 StraitOfBelleIsleBarrens            25.4
9 Western_Forests                     18.9
> > sap_reg_height_low <- sap_reg_height %>%
  +     filter(AverageHeight < 20) %>%
  +     print()
# A tibble: 2 × 2
Ecoregion                  AverageHeight
<chr>                              <dbl>
  1 Northern_Peninsula_Forests          19.9
2 Western_Forests                     18.9
> # Ecoregions with average tree heights less than 20 cm are considered severely browsed by moose
  > # These ecoregions are listed in the sap_reg_height_low output above
  > > library(dplyr)
> > sap_spe_browse <- sap_clean %>%
  +     group_by(Species) %>%
  +     summarize(
    +         AverageBrowsing = mean(BrowsingScore)
    +     ) %>%
  +     print()
# A tibble: 6 × 2
Species        AverageBrowsing
<chr>                    <dbl>
  1 "Alder "                  4.25
2 "Balsam_Fir"              3.14
3 "Black_Ash"               5   
4 "Black_Spruce"            2.33
5 "White_Birch"             3.14
6 "Willow"                  4.31
> avg_browse_spe <- sap_spe_browse %>%
  +     arrange(desc(AverageBrowsing))
> # The species with the highest average browsing score is listed in the first row above
  > # The species with the lowest average browsing score is listed in the last row above
  > > library(dplyr)
> > fir_reg_browse <- sap_clean %>%
  +     filter(Species == "Balsam_Fir") %>%
  +     group_by(Ecoregion) %>%
  +     summarize(
    +         AverageBrowsing = mean(BrowsingScore)
    +     ) %>%
  +     print()
# A tibble: 7 × 2
Ecoregion                  AverageBrowsing
<chr>                                <dbl>
  1 Avalon_Forests                        2   
2 Central_Forests                       3.5 
3 EasternHyperOceanicBarrens            2   
4 Long_Range_Barrens                    1   
5 Maritime_Barrens                      2   
6 North_Shore_Forests                   4.5 
7 Northern_Peninsula_Forests            4.25
> barplot(
  +     fir_reg_browse$AverageBrowsing,
  +     names.arg = fir_reg_browse$Ecoregion,
  +     xlab = "Ecoregion",
  +     ylab = "Average browsing intensity",
  +     main = "Average Balsam Fir browsing intensity by ecoregion",
  +     col = "forestgreen",
  +     cex.names = 0.6
  + )
> library(dplyr)
> > spruce_reg_browse <- sap_clean %>%
  +     filter(Species == "Black_Spruce") %>%
  +     group_by(Ecoregion) %>%
  +     summarize(
    +         AverageBrowsing = mean(BrowsingScore)
    +     ) %>%
  +     print()
# A tibble: 8 × 2
Ecoregion                  AverageBrowsing
<chr>                                <dbl>
  1 Avalon_Forests                         0.5
2 Central_Forests                        3  
3 EasternHyperOceanicBarrens             0  
4 Long_Range_Barrens                     2  
5 Maritime_Barrens                       0  
6 North_Shore_Forests                    4  
7 Northern_Peninsula_Forests             4  
8 Western_Forests                        3.5
> barplot(
  +     spruce_reg_browse$AverageBrowsing,
  +     names.arg = spruce_reg_browse$Ecoregion,
  +     xlab = "Ecoregion",
  +     ylab = "Average browsing intensity",
  +     main = "Average Black Spruce browsing intensity by ecoregion",
  +     col = "darkolivegreen",
  +     cex.names = 0.6
  + )
> # Black Spruce generally shows lower average browsing intensity than Balsam Fir across most ecoregions,
  > # suggesting that moose preferentially browse Balsam Fir compared to Black Spruce.
  > > library(dplyr)
> > sap_reg_tally <- sap_clean %>%
  +     group_by(Ecoregion) %>%
  +     tally() %>%
  +     print()
# A tibble: 9 × 2
Ecoregion                      n
<chr>                      <int>
  1 Avalon_Forests                 5
2 Central_Forests                5
3 EasternHyperOceanicBarrens     5
4 Long_Range_Barrens             5
5 Maritime_Barrens               3
6 North_Shore_Forests            8
7 Northern_Peninsula_Forests     7
8 StraitOfBelleIsleBarrens       1
9 Western_Forests                5
> library(dplyr)
> > sap_spe_tally <- sap_clean %>%
  +     group_by(Species) %>%
  +     tally() %>%
  +     print()
# A tibble: 6 × 2
Species            n
<chr>          <int>
  1 "Alder "           8
2 "Balsam_Fir"      11
3 "Black_Ash"        1
4 "Black_Spruce"     9
5 "White_Birch"      7
6 "Willow"           8
> # The SaplingStudy dataset is not evenly distributed.
  > # Some ecoregions and tree species have many more sampled saplings than others,
  > # indicating that certain regions/species are overrepresented while others are underrepresented.
  > > # Recognizing sampling bias is important because uneven sampling can lead to misleading conclusions
  > # about browsing intensity and ecological patterns that may not accurately represent the entire system.
  > > library(dplyr)
> > moose_2020b <- moose_clean %>%
  +     filter(Year == 2020) %>%
  +     mutate(MooseDensity = Estimated_Moose_Pop / Area)
> > moose_sap <- left_join(
  +     moose_2020b,
  +     sap_clean,
  +     by = "Ecoregion",
  +     relationship = "many-to-many"
  + )
> library(dplyr)
> > sum_spe_browse <- moose_sap %>%
  +     group_by(Species, Ecoregion) %>%
  +     summarize(
    +         AverageBrowsing = mean(BrowsingScore),
    +         AverageMooseDensity = mean(MooseDensity)
    +     ) %>%
  +     print()
`summarise()` has grouped output by
'Species'. You can override using the
`.groups` argument.
# A tibble: 38 × 4
# Groups:   Species [6]
Species      Ecoregion     AverageBrowsing
<chr>        <chr>                   <dbl>
  1 "Alder "     Avalon_Fores…             4  
2 "Alder "     Central_Fore…             4.5
3 "Alder "     EasternHyper…             4  
4 "Alder "     Long_Range_B…             3.5
5 "Alder "     Maritime_Bar…             3.5
6 "Alder "     North_Shore_…             4.5
7 "Alder "     Northern_Pen…             5  
8 "Alder "     Western_Fore…             5  
9 "Balsam_Fir" Avalon_Fores…             2  
10 "Balsam_Fir" Central_Fore…             3.5
# ℹ 28 more rows
# ℹ 1 more variable:
#   AverageMooseDensity <dbl>
# ℹ Use `print(n = ...)` to see more rows
> # The figure provides evidence supporting the researchers’ hypothesis. At low moose density, browsing intensity is higher on preferred species, while at higher moose densities browsing becomes more evenly distributed across species, suggesting a shift toward more generalist feeding behavior.
  > > # Moose appear to favour Balsam Fir the most, as it shows the highest average browsing scores across ecoregions. Black Spruce is browsed the least, with consistently lower average browsing scores.
  > > # The sapling species not shown on the figure is the species with no variation or missing average values (e.g., species absent from certain ecoregions). It is not displayed because ggplot cannot plot species with insufficient or missing summarized data.
  > > # Create vectors
  > collisions2020 <- c(56, 60, 14, 36, 48, 10, 40, 110, 6)
> > human_pop <- c(18000, 12000, 4000, 75100, 24000, 3500, 32000, 270000, 2300)
> > study_sites <- c("North_Shore_Forests",
                     +                  "Northern_Peninsula_Forests",
                     +                  "Long_Range_Barrens",
                     +                  "Central_Forests",
                     +                  "Western_Forests",
                     +                  "EasternHyperOceanicBarrens",
                     +                  "Maritime_Barrens",
                     +                  "Avalon_Forests",
                     +                  "StraitOfBelleIsleBarrens")
> > # Combine vectors into a dataset
  > moose_coll <- data.frame(collisions2020, human_pop, study_sites)
> > # View dataset
  > moose_coll
collisions2020 human_pop
1             56     18000
2             60     12000
3             14      4000
4             36     75100
5             48     24000
6             10      3500
7             40     32000
8            110    270000
9              6      2300
study_sites
1        North_Shore_Forests
2 Northern_Peninsula_Forests
3         Long_Range_Barrens
4            Central_Forests
5            Western_Forests
6 EasternHyperOceanicBarrens
7           Maritime_Barrens
8             Avalon_Forests
9   StraitOfBelleIsleBarrens
> library(dplyr)
> > moose_coll2 <- moose_coll %>%
  +     rename(Ecoregion = study_sites)
> coll_merge <- left_join(moose_2020, moose_coll2, by = "Ecoregion")
> plot(coll_merge$MooseDensity, coll_merge$collisions2020,
       +      xlab = "Moose Density (moose per km²)",
       +      ylab = "Number of Moose-Vehicle Collisions (2020)",
       +      main = "Relationship Between Moose Density and Vehicle Collisions")
> # There is a general positive relationship between moose density and the number of vehicle collisions, with regions of higher moose density tending to have more collisions.
  > # One notable outlier appears to be regions with relatively low moose density but high collision numbers, likely due to higher human population or traffic volume.
  > coll_merge_per_capita <- coll_merge %>%
  +     mutate(coll_per_capita = collisions2020 / human_pop)
> plot(coll_merge_per_capita$human_pop, coll_merge_per_capita$coll_per_capita,
       +      xlab = "Human Population",
       +      ylab = "Moose Collisions per Person",
       +      main = "Moose Collisions per Capita vs Human Population")
> # Moose collisions per capita tend to be higher in regions with smaller human populations, while regions with larger populations show lower collisions per person.
  > # This trend makes sense because rural areas in Newfoundland often have high moose densities and frequent driving on highways through moose habitat, whereas urban areas have more people but relatively fewer moose encounters per individual.
  