library(dplyr)
moosedata <- MoosePopulation
View(MoosePopulation)
moose_clean <-na.omit(moosedata)
moose_sel <-select(moose_clean,Ecoregion,Year,Area,Estimated_Moose_Pop)
min("year")
year_min<-(moose_sel$Year)
max("year")
year_max<-(moose_sel$Year)
year_min<-min(moose_sel$Year)
moose_max<-max(moose_sel$Estimated_Moose_Pop)
moosedata2<-mutate(moose_sel,MooseDensity=Estimated_Moose_Pop/Area)
plot(moosedata2$Year,moosedata2$MooseDensity,xlab="year",ylab="Moose per sq km",main="Moose density in Newfoundland ecoregions over time")
moose_west<-filter(moosedata2,Ecoregion=="Western_Forests")
plot(moose_west$Year,moosedata2$MooseDensity,type="1",xlab="year",ylab="Moose per sq km",main="Moose density in western forest ecoregion over time")
plot(moose_west$Year,moose_west$MooseDensity,type="l",xlab="year",ylab="Moose per sq km",main="Moose density in western forest ecoregions over time")
moose_2020<-filter(moosedata2,Year=="2020")
moose_2020_high<-filter(moosedata2,Ecoregion=="2020",MooseDensity>2)
moose_2020_high_byD<-arrange(moose_2020_high,desc(MooseDensity))
moose_final<-moosedata2%>%
filter(Year==2020)%>%
filter(MooseDensity>2.0)%>% 
arrange(desc(MooseDensity))%>%
print()  
saplings<-read.csv("SaplingStudy.csv")
View(saplings)
sap_clean<-na.omit(saplings)
sap_reg_browse<-sap_clean%>%
group_by(Ecoregion)%>%
summarise(BrowsingScore=mean(BrowsingScore))  
print(sap_reg_browse)
avg_browse_reg<-arrange(sap_reg_browse,desc(BrowsingScore))
print(avg_browse_reg)
#Northern_Peninsula_Forests had the highest average browsing score.
#StraitOfBelleIsleBarrens had the lowest average browsing score.
sap_reg_height<-sap_clean%>%
group_by(Ecoregion)%>%
summarise(Height=mean(Height)) %>% 
print()
sap_reg_height_low<-filter(sap_reg_height,Height<20)
print(sap_reg_height_low)
#The Northern Peninsula and Western Forests have average heights lower than 20
sap_spe_browse<-sap_clean%>%
group_by(Species)%>% 
summarise(BrowsingScore=mean(BrowsingScore))%>%  
print()  
fir_reg_browse<-sap_clean%>%
filter(Species=="Balsam_Fir")%>% 
group_by(Ecoregion) %>%
summarise(BrowsingScore=mean(BrowsingScore))  
barplot(fir_reg_browse$BrowsingScore,names.arg = fir_reg_browse$Ecoregion,xlab="Ecoregion",ylab="Average Browsing Score",main="Average Browsing Score of the Balsam Fir by Ecoregion",col = "purple",cex.names = 0.6)
spruce_reg_browse<-sap_clean%>%
filter(Species=="Black_Spruce")%>%  
group_by(Ecoregion)%>%
summarise(BrowsingScore=mean(BrowsingScore))  
barplot(spruce_reg_browse$BrowsingScore,names.arg = spruce_reg_browse$Ecoregion,xlab="Ecoregion",ylab="Average Browsing Score",main = "Average Browsing Score of the Black Spruce by Ecoregion",col = "green",cex.names = 0.6)
#The Black spruce's browsing score is way more equal in Ecoregions compared to the Balsam Fir which is more diverse,scores for the fir are different in most locations, while the Black Spruce is fairly stable
sap_reg_tally<-sap_clean%>%
group_by(Ecoregion) %>%
tally() %>%
print()  
#different amounts of trees were counted
sap_spe_tally<-sap_clean%>%
group_by(Species)  %>%
tally()  
print(sap_spe_tally)
#there were different numbers counted for each species
#I think it is unevenly distributed because there are different numbers counted for each species with the North Shore Forests being the most over represented and the Strait of Belle Isle Barrens being the least represented for Ecoregion's.The Balsam Fir was overepresented and the Black Ash underrepresented for the Species. 
#I think it is important to recognize bias to insure accuracy in research.
moose_2020b<-moose_clean%>%
filter(Year=="2020")%>%  
mutate(MooseDensity=Estimated_Moose_Pop/Area)  
moose_sap<-left_join(moose_2020b,sap_clean,by='Ecoregion',relationship = "many-to-many")
sum_spe_browse<-moose_sap%>%
group_by(Species,Ecoregion)  %>%
summarise(BrowsingScore=mean(BrowsingScore),MooseDensity=mean(MooseDensity))  %>%
print()
#a) The browsing score of all the species increase when moose density increases.This supports the researches hypothesis.
#b) The most preferred species is the willow, while the least preferred is the Black Spruce.
#c) The Black Ash because it was only measured in one of the Ecoregions. It would be inaccurate results.
collisions2020 <- c(56, 60, 14, 36, 48, 10, 40, 110, 6)
human_pop <- c(18000, 12000, 4000, 75100, 24000,3500, 32000, 270000,    2300)
study_sites <- c("North_Shore_Forests","Northern_Peninsula_Forests", "Long_Range_Barrens","Central_Forests","Western_Forests","EasternHyperOceanicBarrens","Maritime_Barrens","Avalon_Forests","StraitOfBelleIsleBarrens")
moose_coll <- data.frame(collisions2020, human_pop, study_sites)
moose_coll2<-rename(moose_coll,Ecoregion= study_sites)
coll_merge<-left_join(moose_2020,moose_coll2,by='Ecoregion',relationship = "many-to-many")
plot(coll_merge$MooseDensity,coll_merge$collisions2020,type = "p",xlab="MooseDensity",ylab = "Collisions in 2020",main = "Collisions in 2020 vs Moose Density")
#The plot shows for the most part, areas with higher moose density had a increase of collisions in 2020.
coll_merge_per_captia<-mutate(coll_merge,coll_per_captia=collisions2020/human_pop)
plot(coll_merge_per_captia$coll_per_captia,coll_merge_per_captia$human_pop,type = "p",xlab = "Collisions Per Captia",ylab = "Human Population",main = "Collisions Per Captia vs Human Population")
#The plot shows that areas with fewer population tend to have more collisions. This makes sense as moose tend to stick to more wooded areas rather than in big cities where bigger populations live.
