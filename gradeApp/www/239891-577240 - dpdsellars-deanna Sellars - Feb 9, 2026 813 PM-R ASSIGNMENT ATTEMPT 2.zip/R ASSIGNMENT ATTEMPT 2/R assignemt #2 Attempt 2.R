#Name: Deanna Sellars
# Bio R Assignment 1002
# Date: Feb 9th 2026
# Part 1: Moose Population of Newfoundland & Labrador
# Question 1:
installed.packages("dplyr")
library(dplyr)
# Question 2:
moosedata <- read.csv("MoosePopulation.csv")
# Question 3: 
View(moosedata)
moose_clean <- na.omit(moosedata)
View(moose_clean)
#Question 4:
moose_sel <- select(moose_clean, Ecoregion, Year, Area, Estimated_Moose_Pop)
# Question 5A:
year_min <- min(moose_sel$Year)
# The oldest year is 1904
# Question 5B:
moose_max <- max(moose_sel$Estimated_Moose_Pop)
# The highest estimated moose population is 41250
# Question 6:
moosedata2 <- mutate(moose_sel, MooseDensity = Estimated_Moose_Pop / Area)
#Question 7:
plot(moosedata2$Year, moosedata2$MooseDensity, type="l",
xlab = "year",
ylab = "Moose per sq km",
main = "Moose density in Newfoundland ecoregions over time")
#Question 8A:
moose_west <- filter(moosedata2, Ecoregion == "Western_Forests")
#Question 8B:
plot(moose_west$Year, moose_west$MooseDensity, type="l",
xlab = "year",
ylab = "Moose per sq km",
main = "Moose density in western forest ecoregions over time")
# Question 9:
moose_2020 <- filter(moosedata2, Year == 2020)
# Question 9B:
moose_2020_high <- filter(moose_2020, MooseDensity > 2.0)
# Question 9c:
moose_2020_high_ByD <- arrange(moose_2020_high, desc(MooseDensity))
#Question 10:
moosefinal <- moosedata2 %>%
filter(Year == 2020) %>%
filter(MooseDensity > 2.0) %>%
arrange(desc(MooseDensity)) %>%
print()
#Part II: Tree sapling study
#Question 11:
sapling <- read.csv(file = "SaplingStudy.csv")
#Question 11B:
sapling_clean <- na.omit(sapling)
#Question 12:
sap_reg_browse <- sapling_clean %>%
group_by(Ecoregion)%>%
summarize(MeanBrowsingScore = mean(BrowsingScore))%>%
print()
# Question 12B:
avg_browse_reg <- sap_reg_browse %>%
arrange(desc(MeanBrowsingScore))
#the highest region is the Northern Peninsula Forest and the lowest is the Strait Of Belle Isle Barrens
#Question 13A:
sap_reg_height <- sapling_clean %>%
group_by(Ecoregion)%>%
summarize(AverageHeight = mean(Height))%>%
print()
# Question 13B:
sap_reg_height_low <- sap_reg_height %>% 
filter(AverageHeight < 20)
print(sap_reg_height_low)
#the Ecoregion's with a average height less than 20 cm is the Northern Peninsula Forest with 19.9 and the Western Forest of 18.9
#Question 14A
sap_spe_browse <- sapling_clean %>%
group_by(Species)%>%
summarize(MeanBrowsingScore = mean(BrowsingScore))%>%
print()
#Question 14B:
avg_browse_spe<- sap_spe_browse %>%
arrange(desc(MeanBrowsingScore))
print(avg_browse_spe)
# The species that has the highest browsing score is Black Ash and the species of the lowest of Black spruce.
#Question 15:
fir_reg_browse <- sapling_clean %>%
filter(Species == "Balsam_Fir") %>%
group_by(Ecoregion)%>%
summarize(MooseBrowsingScore = mean(BrowsingScore))
#Question 16:
barplot(fir_reg_browse$MooseBrowsingScore, names.arg = fir_reg_browse$Ecoregion, xlab = "different ecoregions", ylab = "average browsing", main = "eroregions and their average browsing", col="deeppink", cex.name = 0.5, las = 2)
# I went to the help center and tried multiple time to find a way to put my x axis labels on a angle but nothing has worked. The TA's also couldn't figure it out!
# Question 17A
spruce_reg_browse <- sapling_clean %>%
filter(Species == "Black_Spruce") %>%
group_by(Ecoregion) %>%
summarize(MooseBrowsingScore = mean(BrowsingScore))
#Question 17B:
barplot(spruce_reg_browse$MooseBrowsingScore, names.arg = spruce_reg_browse$Ecoregion, xlab = "different ecoregion", ylab = "average browsing", main = "ecoregions and their average browsing of black spruce", col = "blue", cex.names = 0.6,las = 3 )
# The Balsam fi Browsing shows that it has a higher browsing than black spruce in most ecoregions that is being measured. A example of this is the North Shore has a moose population of 4.25 in balsam fir compared to the spruce fir browsing which measured 4.0.
#Question 18:
sap_reg_tally<- sapling_clean %>%
group_by(Ecoregion) %>%
tally() %>% 
print()
#Question 19:
sap_spe_tally <- sapling_clean %>%
group_by(Species) %>%
tally() %>% 
print()
#Question 20A:
# The sapling study isn't evenly distributed very well because some of the question asked are only graphing or analyzing a specific specie and leaving some other species and ecoregion's out. Them being sampled more is making these specific groups over presented in the data collection and some are being under presented not making it an accurate representation of trees across the island.
# Question 20B
# It is important to recognize bias because having uneven sampling across a set of data lead to misleading and wrong conclusion. The collector may make the browsing patterns across a set of data appear stronger and or weaker than the data actually is.
# Question 21A
moose_2020b <- filter(moose_2020, Year ==2020)
moose_2020b <- mutate(moose_2020b, MooseDensity =  Estimated_Moose_Pop / Area)
#Question 21B:
moose_sap <- left_join(moose_2020b, sapling_clean, by = 'Ecoregion', relationship = "many-to-many")
#Question 22:
sum_spe_browse <- moose_sap %>%
group_by(Species, Ecoregion)%>%
summarize(mean(BrowsingScore), mean(MooseDensity))%>%
print()
#Question 23A:
#Yes, the browsing  looks more spread out across species at a higher moose density and is more selective at lower density's based on the data.
#Question 23B:
# It appears moose favours willow and balsam fir more and then browse ash the lowest amount.
#Question 23C:
# The missing species Mountain ash in this data set most likely never had enough data to calculate an avrage browsing score therefore couldn't be plotted.
#Question 24:
collisions2020 <- c(56, 60, 14, 36, 48, 10, 40, 110, 6)
human_pop <- c(18000, 12000, 4000, 75100, 24000,3500, 32000, 270000,    2300)
study_sites <- c("North_Shore_Forests","Northern_Peninsula_Forests", "Long_Range_Barrens","Central_Forests","Western_Forests","EasternHyperOceanicBarrens","Maritime_Barrens","Avalon_Forests","StraitOfBelleIsleBarrens")

moose_coll <- data.frame(collisions2020, human_pop, study_sites)
View(moose_coll)
#Question 25:
moose_coll2 <- moose_coll%>%
rename(Ecoregion = study_sites)
# Question 25B:
coll_merge <- left_join(moose_coll2, moose_2020, by = "Ecoregion")
#Question 26A:
plot(coll_merge$MooseDensity, coll_merge$collisons2020,
     xlab = "Moose Density",
     ylab = "Moose-Vehicle Collisions",
     main = "Moose Density vs Collisions")
#Question 26B:
# No there is no clear trend in this plot that is between moose density and collisions. The points are very scattered and one point looks like a outlier because of the high density site present. 
#question 27:
coll_merge_per_capita <- coll_merge %>%
  mutate(coll_merge_per_capita = collisions2020 / human_pop)
#Question 28:
plot(coll_merge_per_capita$human_pop,coll_merge_per_capita$coll_per_capita,
     xlab = "Human Population",
     ylab = "Collisions per Capita",
     main = "Collisions per Capita vs Population")
#Question 25:
#This plot shows a small upward trend, however I can see the points are scattered and uneven. For being in Newfoundland and Labrador this is somewhat reasonable because more people and vehicles on the road cause an increase of chances of getting hit by a moose while traveling. The area in which the moose are located to plays a factor and is probaby more important than the Newfoundland population alone.